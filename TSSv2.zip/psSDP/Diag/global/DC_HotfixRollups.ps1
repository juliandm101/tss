﻿#************************************************
# DC_HotfixRollups.ps1
# Version 1.0.04.02.14: Created script to easily view what rollups are installed for W7/WS2008R2, W8/WS2012, and W8.1/WS2012R2
# Version 1.1.05.16.14: Added W8.1 Update1 (April2014 rollup);  Added OS Version below each heading.
# Version 1.6.10.16.14: Added Oct2014 updates for W8/W8.1
# Date: 2019,2020
# Author: Boyd Benson (bbenson@microsoft.com) +WalterE
# Description: Creates output to easily identify what rollups are installed on W7/WS2008R2 and later.
# Called from: Networking Diagnostics, and all psSDP
#  ToDo: read latest KB# from \xray\xray_WU.psm1 -or- KBonlyRollup_* from RFL
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable

$OutputFile = $Env:ComputerName + "_HotfixRollups.TXT"
$sectionDescription = "Hotfix Rollups"

# Stopping to continue this service, as xray continues to do same job now!
	"==================================================" | Out-File -FilePath $OutputFile -append
	"**Important EOS (End-Of-Service) note**: The output of this file will no longer be accurate (with latest fixes applied) in year 2023, Please lookup file xray_FOUND* for missing hotfixes" | Out-File -FilePath $OutputFile -append
	"  IF the xray_FOUND* file exists, please read and act accordingly, ELSE the system is considered to be up-to-date"| Out-File -FilePath $OutputFile -append
	" - In future, this file *_HotfixRollups.TXT will no longer be part of psSDP output" | Out-File -FilePath $OutputFile -append
	" - SDP/RFLcheck (KB3070416) will provide similiar info on missing updates" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
# 2023: next step: remove DC_HotfixRollups.ps1 from all psSDP collections

function CheckForHotfix ($hotfixID, $title, $Warn="")
{
	$hotfixesWMIQuery = "SELECT * FROM Win32_QuickFixEngineering WHERE HotFixID='KB$hotfixID'"
	$hotfixesWMI = Get-CimInstance -query $hotfixesWMIQuery #_# or PS > Get-HotFix
	$link = "http://support.microsoft.com/kb/" + $hotfixID
	if ($null -eq $hotfixesWMI)
	{
		"No          $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
		If ($Warn -match "Yes") {
			Write-Host "This system is not up-to-date. Many known issues are resolved by applying latest cumulative update!"
			Write-Host -ForegroundColor Red "*** [WARNING] latest OS cumulative KB $hotfixID is missing.`n Please update this machine with recommended Microsoft KB $hotfixID and verify if your issue is resolved."
			$Global:MissingCU = $hotfixID
		}
	}
	else
	{
		"Yes         $hotfixID - $title   ($link)" | Out-File -FilePath $OutputFile -append
	}
}

#----------detect OS version and SKU
	$wmiOSVersion = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem
	[int]$bn = [int]$wmiOSVersion.BuildNumber

if ($bn -match 22621) # Win 11 22H2 = 22621
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 11 22H2" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022303 -title "January 10, 2023-KB5022303 (OS Build 22621.1105)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021255 -title "December 13, 2022-KB5021255 (OS Build 22621.963)"
	CheckForHotfix -hotfixID 5019980 -title "November 8, 2022-KB5019980 (OS Build 22621.819)"
	CheckForHotfix -hotfixID 5019509 -title "October 18, 2022-KB5019509 (OS Build 22621.675) Out-of-band"
	CheckForHotfix -hotfixID 5018427 -title "October 11, 2022-KB5018427 (OS Build 22621.674)"
	CheckForHotfix -hotfixID 5017389 -title "September 30, 2022-KB5017389 (OS Build 22621.608) Preview"
}
elseif ($bn -match 2200) # Win 11 = 22000
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 11 " | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022287 -title "January 10, 2023-KB5022287 (OS Build 22000.1455)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021234 -title "December 13, 2022-KB5021234 (OS Build 22000.1335)"
	CheckForHotfix -hotfixID 5019157 -title "November 15, 2022-KB5019157 (OS Build 22000.1281) Preview"
	CheckForHotfix -hotfixID 5019961 -title "November 8, 2022-KB5019961 (OS Build 22000.1219)"
	CheckForHotfix -hotfixID 5020387 -title "October 17, 2022-KB5020387 (OS Build 22000.1100) Out-of-band"
	CheckForHotfix -hotfixID 5018418 -title "October 11, 2022-KB5018418 (OS Build 22000.1098)"
	CheckForHotfix -hotfixID 5017328 -title "September 13, 2022-KB5017328 (OS Build 22000.978)"
	CheckForHotfix -hotfixID 5016629 -title "August 9, 2022-KB5016629 (OS Build 22000.856)"
	CheckForHotfix -hotfixID 5015814 -title "July 12, 2022-KB5015814 (OS Build 22000.795)"
	CheckForHotfix -hotfixID 5014697 -title "June 14, 2022-KB5014697 (OS Build 22000.739)"
	CheckForHotfix -hotfixID 5013943 -title "May 10, 2022-KB5013943 (OS Build 22000.675)" 
	CheckForHotfix -hotfixID 5012592 -title "April 12, 2022-KB5012592 (OS Build 22000.613)"
	CheckForHotfix -hotfixID 5011493 -title "March 8, 2022-KB5011493 (OS Build 22000.556)"
	CheckForHotfix -hotfixID 5010386 -title "February 8, 2022-KB5010386 (OS Build 22000.493)"
	CheckForHotfix -hotfixID 5009566 -title "January 11, 2022-KB5009566 (OS Build 22000.434)"
	CheckForHotfix -hotfixID 5008215 -title "December 14, 2021-KB5008215 (OS Build 22000.376)"
	CheckForHotfix -hotfixID 5007215 -title "November 9, 2021-KB5007215 (OS Build 22000.318)"
	CheckForHotfix -hotfixID 5006674 -title "October 12, 2021-KB5006674 (OS Build 22000.258)"
}
elseif ($bn -match 20348) # Server 2022 = 20348
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2022 " | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022291 -title "January 10, 2023-KB5022291 (OS Build 20348.1487)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021249 -title "December 13, 2022-KB5021249 (OS Build 20348.1366)"
	CheckForHotfix -hotfixID 5020032 -title "November 22, 2022—KB5020032 (OS Build 20348.1311) Preview"
	CheckForHotfix -hotfixID 5019081 -title "November 8, 2022-KB5019081 (OS Build 20348.1249)"
	CheckForHotfix -hotfixID 5020436 -title "October 17, 2022-KB5020436 (OS Build 20348.1131) Out-of-band"
	CheckForHotfix -hotfixID 5018421 -title "October 11, 2022-KB5018421 (OS Build 20348.1129)"
	CheckForHotfix -hotfixID 5017316 -title "September 13, 2022-KB5017316 (OS Build 20348.1006)"
	CheckForHotfix -hotfixID 5016627 -title "August 9, 2022-KB5016627 (OS Build 20348.887)"
	CheckForHotfix -hotfixID 5015827 -title "July 12, 2022-KB5015827 (OS Build 20348.825)"
	CheckForHotfix -hotfixID 5014678 -title "June 14, 2022-KB5014678 (OS Build 20348.768)"
	CheckForHotfix -hotfixID 5013944 -title "May 10, 2022-KB5013944 (OS Build 20348.707)"
	CheckForHotfix -hotfixID 5012604 -title "April 12, 2022-KB5012604 (OS Build 20348.643)"
	CheckForHotfix -hotfixID 5011497 -title "March 8, 2022-KB5011497 (OS Build 20348.587)"
	CheckForHotfix -hotfixID 5010354 -title "February 8, 2022-KB5010354 (OS Build 20348.524)"
	CheckForHotfix -hotfixID 5009555 -title "January 11, 2022-KB5009555 (OS Build 20348.469)"
	CheckForHotfix -hotfixID 5008223 -title "December 14, 2021-KB5008223 (OS Build 20348.405)"
}
elseif ($bn -match 1904) # 2004 = 19041, 20H2 = 19042, 21H1 = 19043, 21H2 = 19044, 22H2 = 19045
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 20H2/21H1/21H2/22H2 and Windows Server 2019 20H1/20H2/21H1/21H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022282 -title "January 10, 2023-KB5022282 (OS Builds 19043.2486, 19044.2486, and 19045.2486)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021233 -title "December 13, 2022-KB5021233 (OS Builds 19042.2364, 19043.2364, 19044.2364, and 19045.2364)"
	CheckForHotfix -hotfixID 5020030 -title "November 15, 2022-KB5020030 (OS Builds 19042.2311, 19043.2311, 19044.2311, and 19045.2311) Preview)"
	CheckForHotfix -hotfixID 5019959 -title "November 8, 2022-KB5019959 (OS Builds 19042.2251, 19043.2251, 19044.2251, and 19045.2251)"
	CheckForHotfix -hotfixID 5020435 -title "October 17, 2022-KB5020435 (OS Builds 19042.2132, 19043.2132, and 19044.2132) Out-of-band"
	CheckForHotfix -hotfixID 5018410 -title "October 11, 2022-KB5018410 (OS Builds 19042.2130, 19043.2130, and 19044.2130)"
	CheckForHotfix -hotfixID 5017308 -title "September 13, 2022-KB5017308 (OS Builds 19042.2006, 19043.2006, and 19044.2006)" 
	CheckForHotfix -hotfixID 5016616 -title "August 9, 2022-KB5016616 (OS Builds 19042.1889, 19043.1889, and 19044.1889)"
	CheckForHotfix -hotfixID 5015807 -title "July 12, 2022-KB5015807 (OS Builds 19042.1826, 19043.1826, and 19044.1826)"
	CheckForHotfix -hotfixID 5014699 -title "June 14, 2022-KB5014699 (OS Builds 19042.1766, 19043.1766, and 19044.1766)"
	CheckForHotfix -hotfixID 5013942 -title "May 10, 2022-KB5013942 (OS Builds 19042.1706, 19043.1706, and 19044.1706)"
	CheckForHotfix -hotfixID 5012599 -title "April 12, 2022-KB5012599 (OS Builds 19042.1645, 19043.1645, and 19044.1645)" 
	CheckForHotfix -hotfixID 5011487 -title "March 8, 2022-KB5011487 (OS Builds 19042.1586, 19043.1586, and 19044.1586)"
	CheckForHotfix -hotfixID 5010342 -title "February 8, 2022-KB5010342 (OS Builds 19042.1526, 19043.1526, and 19044.1526)"
	CheckForHotfix -hotfixID 5009543 -title "January 11, 2022-KB5009543 (OS Builds 19042.1466, 19043.1466, and 19044.1466)"
	CheckForHotfix -hotfixID 5008212 -title "December 14, 2021-KB5008212 (OS Builds 19041.1415, 19042.1415, 19043.1415, and 19044.1415)"
	CheckForHotfix -hotfixID 4598481 -title "Servicing stack update for Windows 10, version 2004 and 20H2: January 12, 2021"
}
elseif ($bn -match  1836) # 1903 = 18362, 1909 = 18363
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 19H2 v1909 and Windows Server 2019 19H2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5013945 -title "May 10, 2022-KB5013945 (OS Build 18363.2274)" -Warn "Yes"
	CheckForHotfix -hotfixID 5012591 -title "April 12, 2022-KB5012591 (OS Build 18363.2212)"
	CheckForHotfix -hotfixID 5011485 -title "March 8, 2022-KB5011485 (OS Build 18363.2158)"
	CheckForHotfix -hotfixID 5010345 -title "February 8, 2022-KB5010345 (OS Build 18363.2094)"
	CheckForHotfix -hotfixID 5009545 -title "January 11, 2022-KB5009545 (OS Build 18363.2037)"
	CheckForHotfix -hotfixID 5008206 -title "December 14, 2021-KB5008206 (OS Build 18363.1977)"
	CheckForHotfix -hotfixID 5007189 -title "November 9, 2021-KB5007189 (OS Build 18362.1916)"
	CheckForHotfix -hotfixID 5006667 -title "October 12, 2021-KB5006667 (OS Build 18363.1854)"
	CheckForHotfix -hotfixID 5005566 -title "September 14, 2021-KB5005566 (OS Build 18363.1801)"
	CheckForHotfix -hotfixID 5005031 -title "August 10, 2021-KB5005031 (OS Build 18363.1734)"
	CheckForHotfix -hotfixID 5004245 -title "July 13, 2021-KB5004245 (OS Build 18363.1679)"
	CheckForHotfix -hotfixID 5003635 -title "June 8, 2021-KB5003635 (OS Build 18363.1621)"
	CheckForHotfix -hotfixID 4601395 -title "KB4601395: Servicing stack update for Windows 10, version 1903: February 9, 2021"
}
elseif ($bn -eq 17763)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS5 v1809 and Windows Server 2019 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022286  -title "January 10, 2023-KB5022286 (OS Build 17763.3887)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021237 -title "December 13, 2022-KB5021237 (OS Build 17763.3770)"
	CheckForHotfix -hotfixID 5021655 -title "November 17, 2022-KB5021655 (OS Build 17763.3653) Out-of-band"
	CheckForHotfix -hotfixID 5019966 -title "November 8, 2022-KB5019966 (OS Build 17763.3650)"
	CheckForHotfix -hotfixID 5020438 -title "October 17, 2022-KB5020438 (OS Build 17763.3534) Out-of-band"
	CheckForHotfix -hotfixID 5018419 -title "October 11, 2022-KB5018419 (OS Build 17763.3532)"
	CheckForHotfix -hotfixID 5017315 -title "September 13, 2022-KB5017315 (OS Build 17763.3406)"
	CheckForHotfix -hotfixID 5016623 -title "August 9, 2022-KB5016623 (OS Build 17763.3287)"
	CheckForHotfix -hotfixID 5015811 -title "July 12, 2022-KB5015811 (OS Build 17763.3165)"
	CheckForHotfix -hotfixID 5014692 -title "June 14, 2022-KB5014692 (OS Build 17763.3046)"
	CheckForHotfix -hotfixID 5013941 -title "May 10, 2022-KB5013941 (OS Build 17763.2928)"
	CheckForHotfix -hotfixID 5012647 -title "April 12, 2022-KB5012647 (OS Build 17763.2803)"
	CheckForHotfix -hotfixID 5011503 -title "March 8, 2022-KB5011503 (OS Build 17763.2686)"
	CheckForHotfix -hotfixID 5010351 -title "February 8, 2022-KB5010351 (OS Build 17763.2565)"
	CheckForHotfix -hotfixID 5009557 -title "January 11, 2022-KB5009557 (OS Build 17763.2452)"
	CheckForHotfix -hotfixID 5008218 -title "December 14, 2021-KB5008218 (OS Build 17763.2366)"
	CheckForHotfix -hotfixID 4601393 -title "KB4601393: Servicing stack update for Windows 10, version 1809: February 9, 2021"
}
elseif ($bn -eq 14393)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 RS1 v1607 and Windows Server 2016 RS1 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022289 -title "January 10, 2023-KB5022289 (OS Build 14393.5648)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021235 -title "December 13, 2022-KB5021235 (OS Build 14393.5582)"
	CheckForHotfix -hotfixID 5021654 -title "November 17, 2022-KB5021654 (OS Build 14393.5502) Out-of-band"
	CheckForHotfix -hotfixID 5019964 -title "November 8, 2022-KB5019964 (OS Build 14393.5501)"
	CheckForHotfix -hotfixID 5020439 -title "October 18, 2022—KB5020439 (OS Build 14393.5429) Out-of-band"
	CheckForHotfix -hotfixID 5018411 -title "October 11, 2022-KB5018411 (OS Build 14393.5427)"
	CheckForHotfix -hotfixID 5017305 -title "September 13, 2022-KB5017305 (OS Build 14393.5356)"
	CheckForHotfix -hotfixID 5016622 -title "August 9, 2022-KB5016622 (OS Build 14393.5291)"
	CheckForHotfix -hotfixID 5015808 -title "July 12, 2022-KB5015808 (OS Build 14393.5246)"
	CheckForHotfix -hotfixID 5014702 -title "June 14, 2022-KB5014702 (OS Build 14393.5192)"
	CheckForHotfix -hotfixID 5013952 -title "May 10, 2022-KB5013952 (OS Build 14393.5125)"
	CheckForHotfix -hotfixID 5012596 -title "April 12, 2022-KB5012596 (OS Build 14393.5066)"
	CheckForHotfix -hotfixID 5011495 -title "March 8, 2022-KB5011495 (OS Build 14393.5006)"
	CheckForHotfix -hotfixID 5010359 -title "February 8, 2022-KB5010359 (OS Build 14393.4946)"
	CheckForHotfix -hotfixID 5009546 -title "January 11, 2022-KB5009546 (OS Build 14393.4886)"
	CheckForHotfix -hotfixID 5008207 -title "December 14, 2021-KB5008207 (OS Build 14393.4825)"
	CheckForHotfix -hotfixID 4601392 -title "Servicing stack update for Windows 10, version 1607: Februar 9, 2021"
}	
elseif ($bn -eq 10240)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 10 and Windows Server 2016 RTM Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022297 -title "January 10, 2023-KB5022297 (OS Build 10240.19685)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021243 -title "December 13, 2022-KB5021243 (OS Build 10240.19624)"
	CheckForHotfix -hotfixID 5019970 -title "November 8, 2022-KB5019970 (OS Build 10240.19567)"
	CheckForHotfix -hotfixID 5020440 -title "October 18, 2022-KB5020440 (OS Build 10240.19509) Out-of-band"
	CheckForHotfix -hotfixID 5018425 -title "October 11, 2022-KB5018425 (OS Build 10240.19507)"
	CheckForHotfix -hotfixID 5017327 -title "September 13, 2022-KB5017327 (OS Build 10240.19444)" 
	CheckForHotfix -hotfixID 5016639 -title "August 9, 2022-KB5016639 (OS Build 10240.19387)"
	CheckForHotfix -hotfixID 5015832 -title "July 12, 2022-KB5015832 (OS Build 10240.19360)"
	CheckForHotfix -hotfixID 5014710 -title "June 14, 2022-KB5014710 (OS Build 10240.19325)"
	CheckForHotfix -hotfixID 5013963 -title "May 10, 2022-KB5013963 (OS Build 10240.19297)"
	CheckForHotfix -hotfixID 5012653 -title "April 12, 2022-KB5012653 (OS Build 10240.19265)"
	CheckForHotfix -hotfixID 5011491 -title "March 8, 2022-KB5011491 (OS Build 10240.19235)"
	CheckForHotfix -hotfixID 5010358 -title "February 8, 2022-KB5010358 (OS Build 10240.19204)"
	CheckForHotfix -hotfixID 5009585 -title "January 11, 2022-KB5009585 (OS Build 10240.19177)"
	CheckForHotfix -hotfixID 5008230 -title "December 14, 2021-KB5008230 (OS Build 10240.19145)"
	CheckForHotfix -hotfixID 4601390 -title "KB4601390: Servicing stack update for Windows 10: February 9, 2021"
}
elseif ($bn -eq 9600)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 8.1 and Windows Server 2012 R2 Rollups"	 | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022352 -title "January 10, 2023-KB5022352 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021294 -title "December 13, 2022-KB5021294 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5021653 -title "KB5021653: Out-of-band update for Windows Server 2012 R2: November 17, 2022"
	CheckForHotfix -hotfixID 5020023 -title "November 8, 2022-KB5020023 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5018474 -title "October 11, 2022-KB5018474 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5017367 -title "September 13, 2022-KB5017367 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5016681 -title "August 9, 2022-KB5016681 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5015874 -title "July 12, 2022-KB5015874 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5014738 -title "June 14, 2022-KB5014738 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5014011 -title "May 10, 2022-KB5014011 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5012670 -title "April 12, 2022-KB5012670 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5011564 -title "March 8, 2022-KB5011564 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5010419 -title "February 8, 2022-KB5010419 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5009624 -title "January 11, 2022-KB5009624 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5008263 -title "December 14, 2021-KB5008263 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4566425 -title "Servicing stack update for Windows 8.1, RT 8.1, and Server 2012 R2: July 14, 2020"
	CheckForHotfix -hotfixID 4530702 -title "December 10, 2019-KB4530702 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3123245 -title "Update improves port exhaustion identification in Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3179574 -title "August 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3172614 -title "July 2016 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3013769 -title "December 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 3000850 -title "November 2014 update rollup for Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2"
	CheckForHotfix -hotfixID 2919355 -title "[Windows 8.1 Update 1] Windows RT 8.1, Windows 8.1, and Windows Server 2012 R2 Update: April 2014"
	CheckForHotfix -hotfixID 2883200 -title "Windows 8.1 and Windows Server 2012 R2 General Availability Update Rollup"
}
elseif ($bn -eq 9200)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Server 2012 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append
	
	CheckForHotfix -hotfixID 5022348 -title "January 10, 2023-KB5022348 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021285 -title "December 13, 2022-KB5021285 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5021652 -title "KB5021652: Out-of-band update for Windows Server 2012: November 17, 2022"
	CheckForHotfix -hotfixID 5020009 -title "November 8, 2022-KB5020009 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5018457 -title "October 11, 2022-KB5018457 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5017370 -title "September 13, 2022-KB5017370 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5016672 -title "August 9, 2022-KB5016672 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5015863 -title "July 12, 2022-KB5015863 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5014747 -title "June 14, 2022-KB5014747 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5014017 -title "May 10, 2022-KB5014017 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5012650 -title "April 12, 2022-KB5012650 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5011535 -title "March 8, 2022-KB5011535 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5009586 -title "January 11, 2022-KB5009586 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5008277 -title "December 14, 2021-KB5008277 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3179575 -title "August 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3172615 -title "July 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3161609 -title "June 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3156416 -title "May 2016 update rollup for Windows Server 2012"
	CheckForHotfix -hotfixID 3013767 -title "December 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 3000853 -title "November 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2995388 -title "October 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012 "
	CheckForHotfix -hotfixID 2984005 -title "September 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2975331 -title "August 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012"
	CheckForHotfix -hotfixID 2967916 -title "July 2014 update rollup for Windows RT, Windows 8, and Windows Server 2012" 
	CheckForHotfix -hotfixID 2962407 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2014" 
	CheckForHotfix -hotfixID 2955163 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: May 2014"
	CheckForHotfix -hotfixID 2934016 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: April 2014" 	
	CheckForHotfix -hotfixID 2928678 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: March 2014" 	
	CheckForHotfix -hotfixID 2919393 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: February 2014"
	CheckForHotfix -hotfixID 2911101 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: January 2014"
	CheckForHotfix -hotfixID 2903938 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: December 2013"
	CheckForHotfix -hotfixID 2889784 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: November 2013"
	CheckForHotfix -hotfixID 2883201 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: October 2013"
	CheckForHotfix -hotfixID 2876415 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: September 2013"
	CheckForHotfix -hotfixID 2862768 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: August 2013"	
	CheckForHotfix -hotfixID 2855336 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: July 2013"	
	CheckForHotfix -hotfixID 2845533 -title "Windows RT, Windows 8, and Windows Server 2012 update rollup: June 2013"	
	CheckForHotfix -hotfixID 2836988 -title "Windows 8 and Windows Server 2012 Update Rollup: May 2013" 				
	CheckForHotfix -hotfixID 2822241 -title "Windows 8 and Windows Server 2012 Update Rollup: April 2013"				
	CheckForHotfix -hotfixID 2811660 -title "Windows 8 and Windows Server 2012 Update Rollup: March 2013"				
	CheckForHotfix -hotfixID 2795944 -title "Windows 8 and Windows Server 2012 Update Rollup: February 2013"			
	CheckForHotfix -hotfixID 2785094 -title "Windows 8 and Windows Server 2012 Update Rollup: January 2013"				
	CheckForHotfix -hotfixID 2779768 -title "Windows 8 and Windows Server 2012 Update Rollup: December 2012"			
	CheckForHotfix -hotfixID 2770917 -title "Windows 8 and Windows Server 2012 Update Rollup: November 2012"			
	CheckForHotfix -hotfixID 2756872 -title "Windows 8 Client and Windows Server 2012 General Availability Update Rollup"
}
elseif ($bn -eq 7601)
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows 7 and Windows Server 2008 R2 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=7600, SP1=7601)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022338 -title "January 10, 2023—KB5022338 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021291 -title "December 13, 2022-KB5021291 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5021651 -title "KB5021651: Out-of-band update for Windows Server 2008 R2: November 18, 2022"
	CheckForHotfix -hotfixID 5020000 -title "November 8, 2022-KB5020000 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5018454 -title "October 11, 2022-KB5018454 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5017361 -title "September 13, 2022-KB5017361 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5016676 -title "August 9, 2022-KB5016676 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5015861 -title "July 12, 2022-KB5015861 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5014748 -title "June 14, 2022-KB5014748 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5014012 -title "May 10, 2022-KB5014012 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5012626 -title "April 12, 2022-KB5012626 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5011552 -title "March 8, 2022-KB5011552 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5010404 -title "February 8, 2022-KB5010404 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5009610 -title "January 11, 2022-KB5009610 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5008244 -title "December 14, 2021-KB5008244 (Monthly Rollup)"
	CheckForHotfix -hotfixID 3125574 -title "Convenience roll-up update for Windows 7 SP1 and Windows Server 2008 R2 SP1" -Warn "Yes"
	CheckForHotfix -hotfixID 4490628 -title "Servicing stack update for Windows 7 SP1 and Windows Server 2008 R2 SP1: March 12, 2019"
	CheckForHotfix -hotfixID 4580970 -title "Servicing stack update for Windows 7 SP1 and Server 2008 R2 SP1: October 13, 2020"
	CheckForHotfix -hotfixID 4538483 -title "Extended Security Updates (ESU) Licensing Preparation Package for Windows 7 SP1 and Windows Server 2008 R2 SP1"
	CheckForHotfix -hotfixID 2775511 -title "An enterprise hotfix rollup is available for Windows 7 SP1 and Windows Server 2008 R2 SP1"
}
elseif (($bn -eq 6002) -or ($bn -eq 6003))
{
	"==================================================" | Out-File -FilePath $OutputFile -append
	"Windows Vista and Windows Server 2008 Rollups" | Out-File -FilePath $OutputFile -append
	"==================================================" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"OS Version:  " + $bn + "   (RTM=6000, SP2=6002 or 6003)" | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"Installed   Rollup Title and Link" | Out-File -FilePath $OutputFile -append
	"---------   ---------------------" | Out-File -FilePath $OutputFile -append

	CheckForHotfix -hotfixID 5022340 -title "January 10, 2023-KB5022340 (Monthly Rollup)" -Warn "Yes"
	CheckForHotfix -hotfixID 5021289 -title "December 13, 2022-KB5021289 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5021657 -title "KB5021657: Out-of-band update for Windows Server 2008 SP2: November 17, 2022"
	CheckForHotfix -hotfixID 5020019 -title "November 8, 2022-KB5020019 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5018450 -title "October 11, 2022-KB5018450 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5017358 -title "September 13, 2022-KB5017358 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5016669 -title "August 9, 2022-KB5016669 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5015866 -title "July 12, 2022-KB5015866 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5014752 -title "June 14, 2022-KB5014752 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5014010 -title "May 10, 2022-KB5014010 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5012658 -title "April 12, 2022-KB5012658 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5011534 -title "March 8, 2022-KB5011534 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5010384 -title "February 8, 2022-KB5010384 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5009627 -title "January 11, 2022-KB5009627 (Monthly Rollup)"
	CheckForHotfix -hotfixID 5008274 -title "December 14, 2021-KB5008274 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4592498 -title "December 8, 2020-KB4592498 (Monthly Rollup)"
	CheckForHotfix -hotfixID 4517134 -title "Servicing stack update for Windows Server 2008 SP2: September 10, 2019"
	CheckForHotfix -hotfixID 4572374 -title "Servicing stack update for Windows Server 2008 SP2: August 11, 2020"
}

	CollectFiles -filesToCollect $OutputFile -fileDescription "Hotfix Rollups" -SectionDescription $sectionDescription


# SIG # Begin signature block
# MIInlQYJKoZIhvcNAQcCoIInhjCCJ4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAbfepQm3IIATWA
# kmR8sx4JXu30lqxK7gTrsHfNWTRIVqCCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGXUwghlxAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIKHuCOMr9YpH2Oh9loivqyB1
# qUyqZkwQGgEJGuDNUaUaMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQBISjC4jHoijOQidUgAwM7DugenVU4av75NWTThIB16G7G6DsoEDlbx
# u5R3Uq4F6J2eU4ptyZpS/vLnP6ZJedYyCUABtP2odpEPBaHkgFKGYO1VzUdBl8oM
# 9j7ONWtzC99r4yLtOvgBCLexHANMilyfJdDuzrLHptfg0kvhxTHeA3uY+MuXzppU
# XVuKmozhRf9u1K+O3aQEhhPOy9ICH12mGkAWP7CySSOEFHFGFTMESRl/riIrtLHA
# d3qImR6i2oZBIgzMWr0qANveau2gCq1dTVD9aaiko0i77F6jk9gIGo24w8Edi1VY
# XjQMmNizhp7SpSXHVH5zoo2uvmv73OGyoYIW/TCCFvkGCisGAQQBgjcDAwExghbp
# MIIW5QYJKoZIhvcNAQcCoIIW1jCCFtICAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIDXQxOpLYLFGpEF4w+M2KyZyxg6Ycyf2j0e4Lfyo5gCmAgZjmwbp
# PxUYEzIwMjMwMTExMTE0MDEwLjE4OFowBIACAfSggdCkgc0wgcoxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjEyQkMt
# RTNBRS03NEVCMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIRVDCCBwwwggT0oAMCAQICEzMAAAHKT8Kz7QMNGGwAAQAAAcowDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIxMTA0MTkw
# MTQwWhcNMjQwMjAyMTkwMTQwWjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTJCQy1FM0FFLTc0RUIxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQDDAZyr2PnStYSRwtKUZkvB5RV/FdFpSOI+zJo1XE90
# xGzcJV7nyyK78SRpW3u3s81M+Sj+zyU226wB4sSfOSLjjLGTZz16SbwTVJDZhX1v
# z8s7F8pqlny1WU/LHDoOYXM0VCOJ9WbwSJnuUVGhjjjy+lxsEPXyqNg0X/ZndJBy
# Fyx1XU31jpXZYaXnlWYuoVFfn52m12Ot4FfOLdZb1OygIRZxgIErnBiBL21PZJJJ
# PNp7eOZ3DjSD4s4jKtU8XYOjORK2/okEM+/BqFdakoak7usesoX6jsQI39WJAUxn
# Kn+/F4+JQAEM2rMRQjyzuSViZ4de+N5A6r8IzcL9jxuPd8k5udkft4Be9EOfFPxH
# pb+4PWYZQm+/0z0Ey7eeEqkqZLHPM7ku1wwSHa0xfGEwYY0xQ/cM4Qrdf7b8sPVn
# Te6wlOTmkc2gf+AMi9unvzsLDjS2wCmIC+2sdjC5vROoi/xnLraXyfyz8y/8/vrg
# JOqvFxfNqUEeH5fLhc+OZp2c+RknJyncpzNuSD1Bu8mnQf/QWzAdL558Wh+kM0nA
# uHWGz9oyLUr+jMS/v9Ysg+wOArXp9T9rHJuowqTQ07GB6VSMBgqXjBTRjpDir03/
# 0/ABLRyyJ9CFjWihB8AjSIMIJIQBOyUPxtM7S1G2p1wh1q85F6rOg928C/cOvVdd
# DwIDAQABo4IBNjCCATIwHQYDVR0OBBYEFPrH/qVLgRJDwpmF3RGBTtFhczx/MB8G
# A1UdIwQYMBaAFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCG
# Tmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUy
# MFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4w
# XAYIKwYBBQUHMAKGUGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2Vy
# dHMvTWljcm9zb2Z0JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwG
# A1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQAD
# ggIBANjQeSoJLcq4p58Vfz+ub920P3Trp0oSV42quLBmqwzhibwTDhCKo6o7uZah
# hhjgrnLx5dI4co1c5+k7pFtpiPyMI5wkAHm2ouXmGIyBoxsBUuuXWGWLH2yWg7jk
# s43QmmEq9rcPoBUoDs/vyYD2JEdlhRWtGLJ+9CNbGZSfGGKzx+ib3b79EdwRnUOH
# n6niDN54vzhiXTRbKr0RyAEop+CrSUKNY1KrUBQbWwQuWBc5K8pnj+Vdcf4x+Fwd
# 73VYshpmRL8e73B1NPojXgEL3vKEOxlZcCXQgnzTUjpS0QWkKxN47JkEnsIXSt/m
# XEny0T2iM2zKpckq7BWfR7AIyRmrP9wTC/0UTHxCaxnRk2h1O2yX5X11mb55Sswp
# mTo8qwoCu1D6MeR9WweAo4OWh6Wk6YeqBftRs7Q1WciWk/nmBBOpXvq9TvBFelR/
# PsqETcFlc2DAbTl1GcJcPCuGFjP4i1vOzUrVHwjhgwMmNb3QBIKD0l/7HKBEpkYo
# eOjYGzZfJoq43U/oUUIhVc3sqAeX9tmJqQaruTlNDg5crnGSEIeGN2Ae7GPeErkB
# o7L4ZfE7+NvKoZGp5LF/5NM+5aENa6sijfdEwMZ7kNsiaNxtyPp1WFB6+ocKVHU4
# dJ+v7ybWFZEkaULVq1w5YpqMCvA5RGolJWVOHBWAjLMY2aPOMIIHcTCCBVmgAwIB
# AgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMjEwOTMwMTgyMjI1
# WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCC
# AiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAOThpkzntHIhC3miy9ckeb0O
# 1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az/1xPx2b3lVNxWuJ+Slr+uDZn
# hUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V29YZQ3MFEyHFcUTE3oAo4bo3t
# 1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oaezOtgFt+jBAcnVL+tuhiJdxq
# D89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkNyjYtcI4xyDUoveO0hyTD4MmP
# frVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7KMtXAhjBcTyziYrLNueKNiOSW
# rAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRfNN0Sidb9pSB9fvzZnkXftnIv
# 231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SUHDSCD/AQ8rdHGO2n6Jl8P0zb
# r17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoYWmEBc8pnol7XKHYC4jMYcten
# IPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5C4lh8zYGNRiER9vcG9H9stQc
# xWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8FdsaN8cIFRg/eKtFtvUeh17a
# j54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1Kc8Q/y8E7jAdBgNVHQ4EFgQU
# n6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUwUzBRBgwrBgEEAYI3TIN9AQEw
# QTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9E
# b2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoGCCsGAQUFBwMIMBkGCSsGAQQB
# gjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/
# MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJ
# oEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYB
# BQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9v
# Q2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQCdVX38Kq3h
# LB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEztTnXwnE2P9pkbHzQdTltuw8x
# 5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJWAAOwBb6J6Gngugnue99qb74p
# y27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G82jfZfakVqr3lbYoVSfQJL1A
# oL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/AyeixmJ5/ALaoHCgRlCGVJ1ijbC
# HcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI95ko+ZjtPu4b6MhrZlvSP9pEB
# 9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1jdEgssU5HLcEUBHG/ZPkkvnNt
# yo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZKCS6OEuabvshVGtqRRFHqfG3
# rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xBZj1p/cvBQUl+fpO+y/g75LcV
# v7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuPNtq6TPmb/wrpNPgkNWcr4A24
# 5oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvpe784cETRkPHIqzqKOghif9lw
# Y1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCAsswggI0AgEBMIH4oYHQpIHNMIHK
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYDVQQLExxN
# aWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYwJAYDVQQLEx1UaGFsZXMgVFNT
# IEVTTjoxMkJDLUUzQUUtNzRFQjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAo47nlwxPizI8/qcKWDYhZ9qMyqSg
# gYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0B
# AQUFAAIFAOdpHZwwIhgPMjAyMzAxMTExOTM1NTZaGA8yMDIzMDExMjE5MzU1Nlow
# dDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA52kdnAIBADAHAgEAAgIkCzAHAgEAAgIR
# 5DAKAgUA52pvHAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBABdJ/Z1TO22u
# STWXKbvojg9KKFaLankMaEJkTnGamMlAWQbZI2b0ww1lZlFJ/Kt4/US3bzCk49wt
# gxAqYpJwqsLY9HOfYyXAv4/ir2R5ONjQyqLXuOVGNiVE8i8dmPoo2HVBORT4U1Zp
# 0uspclVrK77o3h5giJagZ3zaIkTMxS3gMYIEDTCCBAkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHKT8Kz7QMNGGwAAQAAAcowDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgv9QIGfeTSdR6U5KzW6BLbo+gon+cIw5ihUrHHvXx9MEwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCATPRvzm+tVTayVkCTiO3VIMSTojNkDBUKh
# bAXcrNwa4DCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAAByk/Cs+0DDRhsAAEAAAHKMCIEIMmve2X3SWlUtdmiHYIZAOK+ga6tlikcSfDn
# GZhW9DPhMA0GCSqGSIb3DQEBCwUABIICAIQuvO3LChI6r3ENnjzMwxfGlfUiYDjO
# Q1Ebr/wCnqpzV+8FFrtENHd0UQwgy5vNcJSm5kqzeZi0IPJGkN/zSyKF5WHVmRpJ
# JodZ9AGSBm7S5zQxDP8Fc4LrAnKwhoXCR+U8/HTshJYSiZYNzAUsoI85pTfQJbJb
# /xL1vIyOVfnpuw5TedeMadQfty/DRav5hsRy0xQq0t5xFe61Haq4rVHXXFEeeTNg
# dUgfhLiM07v73EYpOf8wP3p+SWQ57t/+RbQuyDbxyv+Vv6UNQNS32GcPfAnsaqv5
# zOS2AiBMK0Ex7dU8AszaDH9F+Pikn5HEUs+vA5MnT9mc5JjJ7iSF4EvbarH89K6w
# j7FVk98dkUPR/A32n3/UPX0o+6kitpNWN3oaK9YlXHmIk8Qsded2Ara04nT7YDpg
# tJwALGMmIZvaZUrPvJBS25W2PF6yBnqbShcXtNrGJGvk+5xp2NupxXC1r4Nm9a3n
# +WfR8i2fiKFtjRf1pebaBjTcUZ0oKdE8bRZIyG4Sq3NsKcuBRSXXD0tt+On4n0mP
# uLSWMv4/aboiMmYhXqsOqFpllbg3n6O7J/KezwUveuwxof98AkdBpncbJxjSuNcG
# xBHTI2w1R3lsyvLB4c10Fk5zcBt/Yxrkmtf7lLnE3x9fZ4U3U3ZqH41Hl1OmVqYe
# BsnPsa/E5sdY
# SIG # End signature block
