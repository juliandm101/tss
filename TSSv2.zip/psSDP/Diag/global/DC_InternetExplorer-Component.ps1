#***************************************************
# DC_InternetExplorer-Component.ps1
# Version 1.0: HKCU and HKLM locations
# Version 1.1.06.07.13: Added "HKU\.DEFAULT" and "HKU\S-1-5-18" locations. [suggestion:johnfern]
# Version 1.2.07.30.14: Added the parsed output of Trusted Sites and Local Intranet to the new _InternetExplorer_Zones.TXT [suggestion:waltere]
# Version 1.3.08.23.14: Added Protected Mode detection for IE Zones. [suggestion:edb]  TFS264121
# Version 1.4.09.04.14: Fixed exception. Corrected syntax for reading registry value by adding "-ErrorAction SilentlyContinue"
# Date: 2009-2014,2022-11-29
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about Internet Explorer (IE)
# Called from: Networking Diagnostics
#****************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

$sectionDescription = "Internet Explorer"
	
Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSInternetExplorer -Status $ScriptVariable.ID_CTSInternetExplorerDescription

#----------Registry
$OutputFile= $Computername + "_InternetExplorer_reg_output.TXT"
$CurrentVersionKeys =	"HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings",
						"HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings",
						"HKU\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\Internet Settings",
						"HKU\S-1-5-18\Software\Microsoft\Windows\CurrentVersion\Internet Settings"

RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "Internet Explorer registry output" -SectionDescription $sectionDescription

$isServerSku = (Get-CimInstance -Class Win32_ComputerSystem).DomainRole -gt 1
$OutputFile= $Computername + "_InternetExplorer_Zones.TXT"

"===================================================="	| Out-File -FilePath $OutputFile -append
"Internet Explorer Zone Information"					| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. IE Enhanced Security Configuration (IE ESC) [Server SKU Only]"		| Out-File -FilePath $OutputFile -append
"   2. IE Protected Mode Configuration for each IE Zone"	| Out-File -FilePath $outputFile -append
"   3. List of Sites in IE Zone2 `"Trusted Sites`""		| Out-File -FilePath $OutputFile -append
"   4. List of Sites in IE Zone1 `"Local Intranet`""	| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append

"====================================================" 	| Out-File -FilePath $outputFile -append
"IE Enhanced Security Configuration (ESC) [Server SKU Only]" 				| Out-File -FilePath $outputFile -append
"====================================================" 	| Out-File -FilePath $outputFile -append
#detect if IE ESC is enabled/disabled for user/admin
if ($isServerSku -eq $true){
	"`n" | Out-File -FilePath $outputFile -append
	# IE ESC is only used on Server SKUs.
	# Detecting if IE Enhanced Security Configuration is Enabled or Disabled
	#  regkey  : HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}
	#  regvalue: IsInstalled
	$regkey="HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
	$adminIEESC = (Get-ItemProperty -path $regkey).IsInstalled
	if ($adminIEESC -eq '0'){
		"IE ESC is DISABLED for Admin users." | Out-File -FilePath $outputFile -append
	}
	else{
		"IE ESC is ENABLED for Admin users." | Out-File -FilePath $outputFile -append
	}
	#user
	#  regkey  : HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}
	#  regvalue: IsInstalled
	$regkey= "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
	$userIEESC=(Get-ItemProperty -path $regkey).IsInstalled
	if ($userIEESC -eq '0'){
		"IE ESC is DISABLED for non-Admin users." | Out-File -FilePath $outputFile -append
	}
	else{
		"IE ESC is ENABLED for non-Admin users." | Out-File -FilePath $outputFile -append
	}
	"`n`n`n" | Out-File -FilePath $outputFile -append
}
else{
	"IE ESC is only used on Server SKUs. Not checking status." | Out-File -FilePath $outputFile -append
	"`n`n`n" | Out-File -FilePath $outputFile -append
}



#added this section 08.23.14
"====================================================" 	| Out-File -FilePath $outputFile -append
"IE Protected Mode Configuration for each IE Zone" 		| Out-File -FilePath $outputFile -append
"====================================================" 	| Out-File -FilePath $outputFile -append
$zone0 = "Computer"
$zone1 = "Local intranet"
$zone2 = "Trusted sites"
$zone3 = "Internet"
$zone4 = "Restricted sites"
$regkeyZonesHKCU = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones"
$zonesHKCU = Get-ChildItem -path $regkeyZonesHKCU
$regkeyZonesHKLM = "HKLM:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones"
$zonesHKLM = Get-ChildItem -path $regkeyZonesHKLM

# Regvalue 2500 exists by default in HKLM in each zone, but may not exist in HKCU.
for($i=0;$i -le 4;$i++)
{
	if ($i -eq 0) {"IE Protected Mode for Zone0 `"$zone0`":" 	| Out-File -FilePath $outputFile -append }
	if ($i -eq 1) {"IE Protected Mode for Zone1 `"$zone1`":" 	| Out-File -FilePath $outputFile -append }
	if ($i -eq 2) {"IE Protected Mode for Zone2 `"$zone2`":" 	| Out-File -FilePath $outputFile -append }
	if ($i -eq 3) {"IE Protected Mode for Zone3 `"$zone3`":" 	| Out-File -FilePath $outputFile -append }
	if ($i -eq 4) {"IE Protected Mode for Zone4 `"$zone4`":" 	| Out-File -FilePath $outputFile -append }
	$regkeyZoneHKCU = join-path $regkeyZonesHKCU $i
	$regkeyZoneHKLM = join-path $regkeyZonesHKLM $i
	$regvalueHKCU2500Enabled = $false
	$regvalueHKLM2500Enabled = $false

	If (test-path $regkeyZoneHKCU)
	{
		#Moved away from this since it exceptions on W7/WS2008R2:   $regvalueHKCU2500 = (Get-ItemProperty -path $regkeyZoneHKCU).2500
		$regvalueHKCU2500 = Get-ItemProperty -path $regkeyZoneHKCU -name "2500" -ErrorAction SilentlyContinue		
		if ($regvalueHKCU2500 -eq 0){
			#"IE Protected Mode is ENABLED in HKCU. (RegValue 2500 is set to 0.)"
			$regvalueHKCU2500Enabled = $true
		}
		if ($regvalueHKCU2500 -eq 3){
			#"IE Protected Mode is DISABLED in HKCU. (RegValue 2500 is set to 3.)"
			$regvalueHKCU2500Enabled = $false
		}
	}
	If (test-path $regkeyZoneHKLM)
	{
		#Moved away from this since it exceptions on W7/WS2008R2:   $regvalueHKCU2500 = (Get-ItemProperty -path $regkeyZoneHKLM).2500
		$regvalueHKLM2500 = Get-ItemProperty -path $regkeyZoneHKLM -name "2500" -ErrorAction SilentlyContinue
		if ($regvalueHKLM2500 -eq 0){
			#"IE Protected Mode is ENABLED in HKCU. (RegValue 2500 is set to 0.)"
			$regvalueHKLM2500Enabled = $true
		}
		if ($regvalueHKLM2500 -eq 3){
			#"IE Protected Mode is DISABLED in HKCU. (RegValue 2500 is set to 3.)"
			$regvalueHKLM2500Enabled = $false
		}
	}

	If (($regvalueHKCU2500Enabled -eq $true) -and ($regvalueHKLM2500Enabled -eq $true)){
		"  ENABLED (HKCU:enabled; HKLM:enabled)" 	| Out-File -FilePath $outputFile -append
		"`n" | Out-File -FilePath $outputFile -append
	}
	elseif (($regvalueHKCU2500Enabled -eq $true) -and ($regvalueHKLM2500Enabled -eq $false)){
		"  DISABLED (HKCU:enabled; HKLM:disabled)" 	| Out-File -FilePath $outputFile -append
		"`n" | Out-File -FilePath $outputFile -append
	}
	elseif (($regvalueHKCU2500Enabled -eq $false) -and ($regvalueHKLM2500Enabled -eq $true)){
		"  ENABLED (HKCU:disabled; HKLM:enabled)" 	| Out-File -FilePath $outputFile -append
		"`n" | Out-File -FilePath $outputFile -append
	}
	elseif (($regvalueHKCU2500Enabled -eq $false) -and ($regvalueHKLM2500Enabled -eq $false)){
		"  DISABLED (HKCU:disabled; HKLM:disabled)" 	| Out-File -FilePath $outputFile -append
		"`n" | Out-File -FilePath $outputFile -append
	}
}
"`n`n`n" | Out-File -FilePath $outputFile -append


#Build an array with all registry subkeys of $regkey 
$regkeyZoneMapDomains = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\Domains"
$regkeyZoneMapEscDomains = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\EscDomains"
$zoneMapDomains = Get-ChildItem -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\Domains"
$zoneMapDomainsLength = $zoneMapDomains.length

# Creating psobjects
$ieZoneMapDomainsObj = New-Object psobject
$ieZoneMapEscDomainsObj = New-Object psobject
$ieDomainsTrustedSitesObj = New-Object psobject
$ieEscDomainsTrustedSitesObj = New-Object psobject
$ieDomainLocalIntranetObj = New-Object psobject
$ieEscDomainLocalIntranetObj = New-Object psobject

#Loop through each domain and determine what Zone the domain is in using http or https regvalues
$domainCount=0
$trustedSiteCount=0
$localIntranetCount=0
foreach ($domain in $zoneMapDomains)
{
	$domainCount++
	$domainName = $domain.PSChildName
	
	# Add all domains to $ieZoneMapDomainsObj
	Add-Member -InputObject $ieZoneMapDomainsObj -MemberType NoteProperty -Name "Domain$domainCount" -Value $domainName

	$domainRegkey = $regkeyZoneMapDomains + '\' + $domainName
	$domainHttp     = (Get-ItemProperty -path "$domainRegkey").http
	$domainHttps    = (Get-ItemProperty -path "$domainRegkey").https
	$domainSubkeys = Get-ChildItem -path $domainRegkey

	if ($domain.SubKeyCount -ge 1){
		foreach ($subkey in $domainSubkeys){
			$subkeyName = $subkey.PSChildName
			$domainRegkey = $regkeyZoneMapDomains + '\' + $domainName + '\' + $subkeyName
			$fullDomainName = $subkeyName + "." + $domainName
			$domainHttp     = (Get-ItemProperty -path "$domainRegkey").http
			$domainHttps    = (Get-ItemProperty -path "$domainRegkey").https

			if ($domainHttp -eq 2){
				$trustedSiteCount++
				# Add trusted sites to the $ieDomainsTrustedSitesObj
				Add-Member -InputObject $ieDomainsTrustedSitesObj -MemberType NoteProperty -Name "Website$trustedSiteCount`t: HTTP" -Value $fullDomainName
			}			
			if ($domainHttps -eq 2){
				$trustedSiteCount++
				# Add trusted sites to the $ieDomainsTrustedSitesObj
				Add-Member -InputObject $ieDomainsTrustedSitesObj -MemberType NoteProperty -Name "Website$trustedSiteCount`t: HTTPS" -Value $fullDomainName	
			}

			if ($domainHttp -eq 1){
				$localIntranetCount++
				# Add Local Intranet to the $ieDomainLocalIntranetObj
				Add-Member -InputObject $ieDomainLocalIntranetObj -MemberType NoteProperty -Name "Website$localIntranetCount`t: HTTP" -Value $fullDomainName	
			}
			if ($domainHttps -eq 1){
				$localIntranetCount++
				# Add Local Intranet to the $ieDomainLocalIntranetObj
				Add-Member -InputObject $ieDomainLocalIntranetObj -MemberType NoteProperty -Name "Website$localIntranetCount`t: HTTPS" -Value $fullDomainName	
			}
		}
	}
	else
	{
		$fullDomainName = $domainName
		$domainHttp     = (Get-ItemProperty -path "$domainRegkey").http
		$domainHttps    = (Get-ItemProperty -path "$domainRegkey").https
		
		if ($domainHttp -eq 2){
			$trustedSiteCount++
			# Add trusted sites to the $ieDomainsTrustedSitesObj
			Add-Member -InputObject $ieDomainsTrustedSitesObj -MemberType NoteProperty -Name "Website$trustedSiteCount`t: HTTP" -Value $fullDomainName				
		}
		if ($domainHttps -eq 2){
			$trustedSiteCount++
			# Add trusted sites to the $ieDomainsTrustedSitesObj
			Add-Member -InputObject $ieDomainsTrustedSitesObj -MemberType NoteProperty -Name "Website$trustedSiteCount`t: HTTPS" -Value $fullDomainName		
		}

		if ($domainHttp -eq 1){
			$localIntranetCount++
			# Add Local Intranet to the $ieDomainLocalIntranetObj
			Add-Member -InputObject $ieDomainLocalIntranetObj -MemberType NoteProperty -Name "Website$localIntranetCount`t: HTTP" -Value $fullDomainName	
		}
		if ($domainHttps -eq 1){
			$localIntranetCount++
			# Add Local Intranet to the $ieDomainLocalIntranetObj
			Add-Member -InputObject $ieDomainLocalIntranetObj -MemberType NoteProperty -Name "Website$localIntranetCount`t: HTTPS" -Value $fullDomainName	
		}	
	}
}

if ($isServerSku -eq $true)
{
	#Loop through each domain and determine what Zone the domain is in using http or https regvalues
	$zoneMapEscDomains = Get-ChildItem -path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\EscDomains"
	$zoneMapEscDomainsLength = $zoneMapEscDomains.length

	$escDomainCount=0
	$trustedSiteCount=0
	$localIntranetCount=0
	if($null -ne $zoneMapEscDomains){ #_#
		foreach ($domain in $zoneMapEscDomains){
			$escDomainCount++
			$domainName = $domain.PSChildName

			# Add domains to $ieZoneMapEscDomainsObj
			Add-Member -InputObject $ieZoneMapEscDomainsObj -MemberType NoteProperty -Name "EscDomain$escDomainCount" -Value $domainName

			$domainRegkey = $regkeyZoneMapEscDomains + '\' + $domainName
			$domainHttp     = (Get-ItemProperty -path "$domainRegkey" -ErrorAction Ignore).http
			$domainHttps    = (Get-ItemProperty -path "$domainRegkey" -ErrorAction Ignore).https
			$domainSubkeys = Get-ChildItem -path $domainRegkey -ErrorAction Ignore

			if ($domain.SubKeyCount -ge 1){
				foreach ($subkey in $domainSubkeys){
					$subkeyName = $subkey.PSChildName
					$domainRegkey = $regkeyZoneMapEscDomains + '\' + $domainName + '\' + $subkeyName
					$fullDomainName = $subkeyName + "." + $domainName
					$domainHttp     = (Get-ItemProperty -path "$domainRegkey" -ErrorAction Ignore).http
					$domainHttps    = (Get-ItemProperty -path "$domainRegkey" -ErrorAction Ignore).https

					if ($domainHttp -eq 2){
						$trustedSiteCount++
						# Add trusted sites to the $ieEscDomainsTrustedSitesObj
						Add-Member -InputObject $ieEscDomainsTrustedSitesObj -MemberType NoteProperty -Name "Website$trustedSiteCount`t: HTTP" -Value $fullDomainName
					}
					if ($domainHttps -eq 2){
						$trustedSiteCount++
						# Add trusted sites to the $ieEscDomainsTrustedSitesObj
						Add-Member -InputObject $ieEscDomainsTrustedSitesObj -MemberType NoteProperty -Name "Website$trustedSiteCount`t: HTTPS" -Value $fullDomainName
					}

					if ($domainHttp -eq 1){
						$localIntranetCount++
						# Add Local Intranet to the $ieEscDomainLocalIntranetObj
						Add-Member -InputObject $ieEscDomainLocalIntranetObj -MemberType NoteProperty -Name "Website$localIntranetCount`t: HTTP" -Value $fullDomainName	
					}
					if ($domainHttps -eq 1){
						$localIntranetCount++
						# Add Local Intranet to the $ieEscDomainLocalIntranetObj
						Add-Member -InputObject $ieEscDomainLocalIntranetObj -MemberType NoteProperty -Name "Website$localIntranetCount`t: HTTPS" -Value $fullDomainName	
					}		
				}
			}
			else
			{
				$fullDomainName = $domainName
				$domainHttp     = (Get-ItemProperty -path "$domainRegkey" -ErrorAction Ignore).http
				$domainHttps    = (Get-ItemProperty -path "$domainRegkey" -ErrorAction Ignore).https
				
				if ($domainHttp -eq 2){
					$trustedSiteCount++
					# Add trusted sites to the $ieEscDomainsTrustedSitesObj
					Add-Member -InputObject $ieEscDomainsTrustedSitesObj -MemberType NoteProperty -Name "Website$trustedSiteCount`t: HTTP" -Value $fullDomainName	
				}
				if ($domainHttps -eq 2){
					$trustedSiteCount++
					# Add trusted sites to the $ieEscDomainsTrustedSitesObj
					Add-Member -InputObject $ieEscDomainsTrustedSitesObj -MemberType NoteProperty -Name "Website$trustedSiteCount`t: HTTPS" -Value $fullDomainName	
				}

				if ($domainHttp -eq 1){
					$localIntranetCount++
					# Add Local Intranet to the $ieEscDomainLocalIntranetObj
					Add-Member -InputObject $ieEscDomainLocalIntranetObj -MemberType NoteProperty -Name "Website$localIntranetCount`t: HTTP" -Value $fullDomainName	
				}
				if ($domainHttps -eq 1){
					$localIntranetCount++
					# Add Local Intranet to the $ieEscDomainLocalIntranetObj
					Add-Member -InputObject $ieEscDomainLocalIntranetObj -MemberType NoteProperty -Name "Website$localIntranetCount`t: HTTPS" -Value $fullDomainName	
				}		
			}
		}
	}
}



"====================================================" 				| Out-File -FilePath $outputFile -append
"List of Sites in IE Zone2 `"Trusted Sites`""						| Out-File -FilePath $outputFile -append
"====================================================" 				| Out-File -FilePath $outputFile -append
if ($isServerSku -eq $true)
{
	"--------------------" 											| Out-File -FilePath $outputFile -append
	"[ZoneMap\Domains registry location]" 							| Out-File -FilePath $outputFile -append
	  "Used when IE Enhanced Security Configuration is Disabled" 	| Out-File -FilePath $outputFile -append
	"--------------------" 											| Out-File -FilePath $outputFile -append
	$ieDomainsTrustedSitesObj | Format-List							| Out-File -FilePath $outputFile -append
	"`n" 															| Out-File -FilePath $outputFile -append
	"`n" 															| Out-File -FilePath $outputFile -append
	"`n" 															| Out-File -FilePath $outputFile -append
	"--------------------" 											| Out-File -FilePath $outputFile -append
	"[ZoneMap\EscDomains registry location]" 						| Out-File -FilePath $outputFile -append
	"Used when IE Enhanced Security Configuration is Enabled" 		| Out-File -FilePath $outputFile -append
	"--------------------" 											| Out-File -FilePath $outputFile -append
	$ieEscDomainsTrustedSitesObj | Format-List						| Out-File -FilePath $outputFile -append
}
else
{
	"--------------------" 											| Out-File -FilePath $outputFile -append
	"[ZoneMap\Domains registry location]" 							| Out-File -FilePath $outputFile -append
	"--------------------" 											| Out-File -FilePath $outputFile -append
	$ieDomainsTrustedSitesObj | Format-List							| Out-File -FilePath $outputFile -append
}
"`n" | Out-File -FilePath $outputFile -append
"`n" | Out-File -FilePath $outputFile -append
"`n" | Out-File -FilePath $outputFile -append




"====================================================" | Out-File -FilePath $outputFile -append
"List of Sites in IE Zone1 `"Local Intranet`"" | Out-File -FilePath $outputFile -append
"====================================================" | Out-File -FilePath $outputFile -append
if ($isServerSku -eq $true)
{
	"--------------------" 										| Out-File -FilePath $outputFile -append
	"[ZoneMap\Domains registry location]" 						| Out-File -FilePath $outputFile -append
	"Used when IE Enhanced Security Configuration is Disabled" 	| Out-File -FilePath $outputFile -append
	"--------------------" 										| Out-File -FilePath $outputFile -append
	$ieDomainLocalIntranetObj | Format-List						| Out-File -FilePath $outputFile -append
	"`n" 														| Out-File -FilePath $outputFile -append
	"`n" 														| Out-File -FilePath $outputFile -append
	"`n" 														| Out-File -FilePath $outputFile -append
	"--------------------" 										| Out-File -FilePath $outputFile -append
	"[ZoneMap\EscDomains registry location]" 					| Out-File -FilePath $outputFile -append
	"Used when IE Enhanced Security Configuration is Enabled" 	| Out-File -FilePath $outputFile -append
	"--------------------" 										| Out-File -FilePath $outputFile -append
	$ieEscDomainLocalIntranetObj | Format-List					| Out-File -FilePath $outputFile -append
}
else
{
	"--------------------" 										| Out-File -FilePath $outputFile -append
	"[ZoneMap\Domains registry location]" 						| Out-File -FilePath $outputFile -append
	"--------------------" 										| Out-File -FilePath $outputFile -append
	$ieDomainLocalIntranetObj | Format-List						| Out-File -FilePath $outputFile -append
}
"`n" | Out-File -FilePath $outputFile -append
"`n" | Out-File -FilePath $outputFile -append
"`n" | Out-File -FilePath $outputFile -append

CollectFiles -sectionDescription $sectionDescription -fileDescription "IE Zones Information (Trusted Sites and Local Intranet)" -filesToCollect $outputFile


# SIG # Begin signature block
# MIInoAYJKoZIhvcNAQcCoIInkTCCJ40CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA0dXm+uKMJBsUy
# HbGT+EAhwdfF/78NIycRiLK/iMd4v6CCDXYwggX0MIID3KADAgECAhMzAAACy7d1
# OfsCcUI2AAAAAALLMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjIwNTEyMjA0NTU5WhcNMjMwNTExMjA0NTU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC3sN0WcdGpGXPZIb5iNfFB0xZ8rnJvYnxD6Uf2BHXglpbTEfoe+mO//oLWkRxA
# wppditsSVOD0oglKbtnh9Wp2DARLcxbGaW4YanOWSB1LyLRpHnnQ5POlh2U5trg4
# 3gQjvlNZlQB3lL+zrPtbNvMA7E0Wkmo+Z6YFnsf7aek+KGzaGboAeFO4uKZjQXY5
# RmMzE70Bwaz7hvA05jDURdRKH0i/1yK96TDuP7JyRFLOvA3UXNWz00R9w7ppMDcN
# lXtrmbPigv3xE9FfpfmJRtiOZQKd73K72Wujmj6/Su3+DBTpOq7NgdntW2lJfX3X
# a6oe4F9Pk9xRhkwHsk7Ju9E/AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUrg/nt/gj+BBLd1jZWYhok7v5/w4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ3MDUyODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAJL5t6pVjIRlQ8j4dAFJ
# ZnMke3rRHeQDOPFxswM47HRvgQa2E1jea2aYiMk1WmdqWnYw1bal4IzRlSVf4czf
# zx2vjOIOiaGllW2ByHkfKApngOzJmAQ8F15xSHPRvNMmvpC3PFLvKMf3y5SyPJxh
# 922TTq0q5epJv1SgZDWlUlHL/Ex1nX8kzBRhHvc6D6F5la+oAO4A3o/ZC05OOgm4
# EJxZP9MqUi5iid2dw4Jg/HvtDpCcLj1GLIhCDaebKegajCJlMhhxnDXrGFLJfX8j
# 7k7LUvrZDsQniJZ3D66K+3SZTLhvwK7dMGVFuUUJUfDifrlCTjKG9mxsPDllfyck
# 4zGnRZv8Jw9RgE1zAghnU14L0vVUNOzi/4bE7wIsiRyIcCcVoXRneBA3n/frLXvd
# jDsbb2lpGu78+s1zbO5N0bhHWq4j5WMutrspBxEhqG2PSBjC5Ypi+jhtfu3+x76N
# mBvsyKuxx9+Hm/ALnlzKxr4KyMR3/z4IRMzA1QyppNk65Ui+jB14g+w4vole33M1
# pVqVckrmSebUkmjnCshCiH12IFgHZF7gRwE4YZrJ7QjxZeoZqHaKsQLRMp653beB
# fHfeva9zJPhBSdVcCW7x9q0c2HVPLJHX9YCUU714I+qtLpDGrdbZxD9mikPqL/To
# /1lDZ0ch8FtePhME7houuoPcMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGYAwghl8AgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAALLt3U5+wJxQjYAAAAAAsswDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIA3r7cDV8iqTmYkCE4ue1h1y
# zmexiCFZWzNCepWM/q9FMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3dy5taWNyb3NvZnQuY29tIDANBgkqhkiG9w0B
# AQEFAASCAQB6GCyZn6lORZ7cHe/AlPPMYC98FpSJX9gOt+eNV8Chw0mhNPinCQzB
# DLyiBjWIsPXWYcSUQZRJblEKhp5MeVnIOlsIap6GK9ky6IdgaF0ia27y66o8eeRV
# K71lXnBcwx6ffgtH4wsmJurGpynjs6WngAW9O+p5dgZCkTlCP7nO7sTSCEjRRQu1
# n1cnxx1IWZhf8hKaJCCvY4f375z9XlbRrX7NY1UtnEZZliQL6r25Rof+m4GURS+E
# EBKs3VwjAYuUcl7uKFaLi/5IUW8V+1S5lnuMrH93iIcyuKDPyaiOvMwrDDIy4kv7
# KlidyybpFoQe6Vyc/LnGvqqyzdQ+Au83oYIXCDCCFwQGCisGAQQBgjcDAwExghb0
# MIIW8AYJKoZIhvcNAQcCoIIW4TCCFt0CAQMxDzANBglghkgBZQMEAgEFADCCAVQG
# CyqGSIb3DQEJEAEEoIIBQwSCAT8wggE7AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIEVXrvxinbhNGQ3poCD7TvX3txEWfY/QAb+Wr37vzlHpAgZjc4Vk
# w+UYEjIwMjIxMTMwMTU1NTE0LjQ5WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkM0
# QkQtRTM3Ri01RkZDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIRXDCCBxAwggT4oAMCAQICEzMAAAGj+5qzjnuGQ08AAQAAAaMwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjIwMzAy
# MTg1MTE2WhcNMjMwNTExMTg1MTE2WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkM0QkQtRTM3Ri01RkZD
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkq
# hkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA771Nyst7KgpwKots23Ps23Yls/VMTPMy
# GLziBLpgsjsIXp1VIDkjVsUIdzDpkXZ4XxCJp/SjZdJd/+OnmyCZRi0xsaLid4C1
# ZI0rnKG3iLJCEHGfRMhCoX42KyIHFb56ExhYRsUj7txJ1f91bD79jz8y726rdcIr
# k/Yb5mJtXA5Uf3n4iJMaeahzFaB2zSqUGlrWtiDduXxdV7kvapNSYkG+dCnHZtSu
# 7vSW3b8ehTlsFssoCEI+nHLieayt05Hca/hRt8Ca2lCe0/vnw1E+GDVsAIfToWW9
# sjI/z+5GzfHbfbd1poaklBhChmkAGDrasUNMnj57Tq237Ft++nwz2WjxrVqB/FlD
# WkhPVWcl1o73yBYyIxbrl14VSJRH5aeBBV+/aAuy/qjv45ynPLpEdkibpYQZn0sG
# 3nvU18KzHnPQiW+vpLM3RBtpYlMshZtfBtRUph5utcRUUzKG5UZAd6xkH5XBXfzq
# FiiczGzSO8zwak5zHTEvLKbjZcD31VKmy6K9MmDijxrUAIltMFUWgQDdWsVJjM51
# Dq/NfGvHDqL9PXfyb5cX7Iq0ASeGn5R4AyGXDuM/30QCWAZSXQqRwGNNhPP6MTI+
# App2tTWh/mgWL+r1gOWtW/0fgmxV7wYcw6Q9M2gHjTbyPzw4R7jboGx9xcuSLSmE
# +nuKtbQBtF0CAwEAAaOCATYwggEyMB0GA1UdDgQWBBRQUfuzPCYIsc9NL0GjaKsu
# cmOLqjAfBgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBW
# MFSgUqBQhk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNy
# b3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUH
# AQEEYDBeMFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# b3BzL2NlcnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEp
# LmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3
# DQEBCwUAA4ICAQBa8t6naZfDqK4HEa7Q+yy2ZcjmAuaA+RMpCeOBmWyh6Kmy1r2i
# S7QxNXGUdV1x0FsVxUcwtFGRQUiR8qdpyXKXl7KPTfB4Ppv+lR8XINkHwBmkZReF
# Ngs1Hw96kzrIPqD7QTWcfQyE4agTpcW5+Rufp4h01Ma5bAF4SvYM2IaEMaXBpQfk
# QvPeG27IzJYoCBgXbwLiLLKFh2+Ub1U3omcLiZz8Qi3nQEIenxlACTscLdE6W2DW
# C7k2MZpJV2KxqLk4lZ/p7mxhB0ME1gpcl2Id6LU3sr4vmzW9X4Lp3dOwX34A2mKg
# EMA4acVJi3g/661bXWLfuIsstv3bqkIvgvL74ZTTCXNh+fufbZHJCa8PXWjKJkeG
# ZGywMGqwD6e8JW1+cfXzcN/mgEFWyTNlwlNSMLFpqAMrsCoHpADcfuX/ZIV56p9f
# 8O12V7gH689XiWrUIKzQDUsH2WbNLS/GhEO6xjzQNCLXQrdJ9krWHLJqP1ryltkb
# QGwGnY3BzjG04MR4FNagDMX2SjhXp3T24UWkmsuhX57xwlT+FPf5KVbt2evl21i/
# OIdOlm65G/gpToXc5DM2kd/twEulYpFdGMZh1WcAZvw3NbrBZONmMwI10IUbumQo
# sw4Z2o8MV1+T4RgTlFIb3LFLvpw99epEpW0llJwgXrh6OddsUizluHwrATCCB3Ew
# ggVZoAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1p
# Y3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkz
# MDE4MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5
# osvXJHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVri
# fkpa/rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFEx
# N6AKOG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S
# /rboYiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3j
# tIckw+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKy
# zbnijYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX78
# 2Z5F37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjt
# p+iZfD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2
# AuIzGHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb
# 3BvR/bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3ir
# Rbb1Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUB
# BAUCAwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYD
# VR0OBBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGC
# N0yDfQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9w
# a2lvcHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8E
# TzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBM
# MEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEA
# nVV9/Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx8
# 0HU5bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ
# 7nvfam++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2
# KFUn0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZ
# QhlSdYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa
# 2Zb0j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARx
# v2T5JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRr
# akURR6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6T
# vsv4O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4
# JDVnK+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6
# ijoIYn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggLPMIICOAIBATCB/KGB
# 1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcG
# A1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsT
# HVRoYWxlcyBUU1MgRVNOOkM0QkQtRTM3Ri01RkZDMSUwIwYDVQQDExxNaWNyb3Nv
# ZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQAeX+leQswBs9qk
# LBr4ZdzdKUMNE6CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MA0GCSqGSIb3DQEBBQUAAgUA5zHKBzAiGA8yMDIyMTEzMDE2MjQzOVoYDzIwMjIx
# MjAxMTYyNDM5WjB0MDoGCisGAQQBhFkKBAExLDAqMAoCBQDnMcoHAgEAMAcCAQAC
# AhnQMAcCAQACAhHFMAoCBQDnMxuHAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisG
# AQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQAD
# gYEAHtv+SoGRAXvTD2N9n5lt9j/LbPFePHHpt2sA2wGcOLtDVgqoZwLg0g03GIaQ
# Q+qebYJpGKmZzemrm/r3tIyGuYPdquiZhJ1wF4CeHtm0v6AwFj2o6VTbzb2SP228
# BmrzWoIRGRo4TypUt9G86m9AMqcQvibX+SMd90atF5PWgC8xggQNMIIECQIBATCB
# kzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAaP7mrOOe4ZDTwAB
# AAABozANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJ
# EAEEMC8GCSqGSIb3DQEJBDEiBCDHYamNp8c3DJFox5f/lDHLe45lJnEqjjbDKkF+
# LypfTzCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIIz4uLAGccwyg53+yBtp
# jGnC8QmVERmX+lM+SXPp643+MIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTACEzMAAAGj+5qzjnuGQ08AAQAAAaMwIgQgJT8VECx+MLxQN1TSG6zQ
# 5LPPkoVqg+Sv34JRTQv1A0swDQYJKoZIhvcNAQELBQAEggIANlo/EVRkF3XFiWYV
# Eq1bYliMvRF1XSqQCeB5B5wNqX4K70f6CErdl5UXx65/XvZp1E/4whHyZbb3PhPQ
# mpRmUva3bIYuaNK4F8iOOmaxhMT1SCKRDy/y3RZQ30ntL3B5+eL4+VbWvCai2say
# CnEQoxIB6qcrVWgiluOtup9UE9wyI/y4cund24cP+zljsPNU1nr/W00wE26bUhQz
# fJyFTptns81NKT8+kh7mvCMOxPakPVH23IhRO8d8E0uiC1+sOP/sV7PpfToTmQ1i
# 9rQ8Ex3IYu+qcTdpADjpA4iqfppW4dqDlSGmEkBGT8WN3gJ3HqhF2epd32ly6ZzE
# x7+GRYAbe4F0qJisXIy/VOnJLRHgijTDr14M/pxMD9IufY4SmgS+klh2N0l5jhdo
# 3R//7wlpCZOZjQ1Y1tunlGC5cUWZeaRjOLAfWZmb+jrDKH8Tgi9QyHwrTsHZyVHP
# Jn49cYClf7NX6TONiQZcS9VTmuRUD75CQAcIOZR8lCY6T1WUyUBximixwIfM0Fat
# VbL7gPWuQbaPBngaEoJX4K6Eav1jOhCrVLymxDoCBAB+UbJPjHck27olLekfwO4M
# cPY8r2CEbsOcazmEdNzghXoE4Y84ztfGuvvj1NWnhRe4zI6DOF6eDBGUwhgpceua
# MK3Sjq4IDe5KJhNDDIyCk3sv6QE=
# SIG # End signature block
